# # import os
# # import django

# # # Set up Django environment
# # os.environ.setdefault("DJANGO_SETTINGS_MODULE", "trading_system.settings")
# # django.setup()

# # from trading.models import Stoploss_Order  # Adjust this based on your model name

# # def clear_stoploss_orders():
# #     """Deletes all records in the StopLossOrder table."""
# #     deleted_count, _ = Stoploss_Order.objects.all().delete()
# #     print(f"Deleted {deleted_count} records from trading_stoplossorder.")

# # if __name__ == "__main__":
# #     clear_stoploss_orders()

# import os
# import django

# # Set up Django environment
# os.environ.setdefault("DJANGO_SETTINGS_MODULE", "trading_system.settings")
# django.setup()

# from django.apps import apps

# def list_models_and_data():
#     """Lists all models, their fields, and all data from the database."""
#     for model in apps.get_models():
#         print(f"Table: {model._meta.db_table}")
#         print("Columns:", [field.name for field in model._meta.fields])
        
#         data = model.objects.all()
#         if data.exists():
#             for obj in data:
#                 print([getattr(obj, field.name) for field in model._meta.fields])
#         else:
            
#             print("  No records found.")

#         print("-" * 40)

# if __name__ == "__main__":
#     list_models_and_data()


# import os
# import django

# # Set up Django environment
# os.environ.setdefault("DJANGO_SETTINGS_MODULE", "trading_system.settings")
# django.setup()

# from django.apps import apps

# def list_table_names():
#     """Lists all database table names."""
#     print("Database Tables:")
#     for model in apps.get_models():
#         print(model._meta.db_table)

# if __name__ == "__main__":
#     list_table_names()


import os
import django

# Set up Django environment
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "trading_system.settings")
django.setup()

from trading.models import Stoplossorder  # Replace 'yourapp' with your actual app name

def delete_stoploss_orders():
    """Deletes all records from the StopLossOrder table."""
    count = Stoplossorder.objects.count()
    if count > 0:
        Stoplossorder.objects.all().delete()
        print(f"Deleted {count} StopLossOrder records.")
    else:
        print("No records found in StopLossOrder.")

if __name__ == "__main__":
    delete_stoploss_orders()
